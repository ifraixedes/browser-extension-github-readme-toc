Browser Extension Github Readme TOC ChangeLog
=============================================

## 2015-08-03, Version 0.0.3

Improvements:
  * TOC float when the page is scrolled down to be always visible

## 2015-07-12, Version 0.0.2

Improvements:
  * Each header level unless 1 (h1) is idented a little bit more than previous level to be able to identify README subsections

## 2014-06-23, Version 0.0.1

First release
